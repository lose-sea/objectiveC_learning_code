//
//  VCRoot.h
//  Appearance 专题练习
//
//  Created by lose_sea on 2026/4/16.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VCRoot : UIViewController <UISearchControllerDelegate>

@end

NS_ASSUME_NONNULL_END
